package com.nexa.toolkit.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexaDark = darkColorScheme(
    primary = Color(0xFF8AA4FF),
    onPrimary = Color(0xFF0A1033),
    primaryContainer = Color(0xFF2B3A78),
    secondaryContainer = Color(0xFF263052),
    onSecondaryContainer = Color(0xFFDDE3FF),
    background = Color(0xFF0D1016),
    surface = Color(0xFF0D1016),
    surfaceVariant = Color(0xFF1A1F2B),
    onSurface = Color(0xFFE3E6EE),
    onSurfaceVariant = Color(0xFFA7ADBD),
)

private val NexaLight = lightColorScheme(
    primary = Color(0xFF3050D0),
    secondaryContainer = Color(0xFFDDE3FF),
)

/** Dark-first: the app starts dark and the user can switch. */
@Composable
fun NexaTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) NexaDark else NexaLight, content = content)
}
