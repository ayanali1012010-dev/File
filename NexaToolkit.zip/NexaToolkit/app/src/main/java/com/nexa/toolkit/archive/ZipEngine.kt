package com.nexa.toolkit.archive

import com.nexa.toolkit.util.PathSafety
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.coroutines.cancellation.CancellationException

class ArchiveException(message: String, cause: Throwable? = null) : IOException(message, cause)
class OperationCancelledException : CancellationException("Operation cancelled")

enum class OverwritePolicy { SKIP, FAIL }

data class ZipItem(val name: String, val isDirectory: Boolean, val size: Long, val compressedSize: Long)
data class ExtractResult(val files: Int, val directories: Int, val skipped: Int, val bytes: Long)

/** Destination abstraction so extraction logic is testable without Android. */
interface ExtractTarget {
    fun exists(path: String): Boolean
    fun createDirectory(path: String)
    fun openOutput(path: String): OutputStream
    fun delete(path: String)
}

/** One item to add to a new archive. [open] is called lazily, only for files. */
class ZipSource(val path: String, val isDirectory: Boolean, val open: () -> InputStream?)

/**
 * Streaming ZIP implementation on java.util.zip. Memory use is bounded by a fixed buffer.
 * Limitations: streaming reads cannot handle ZIPs with prepended data, and listing has to
 * inflate-skip each entry (central-directory listing needs random access to a File).
 * No password/AES support and no 7z/RAR support in this build.
 */
object ZipEngine {
    const val DEFAULT_MAX_TOTAL_BYTES = 16L * 1024 * 1024 * 1024
    const val DEFAULT_MAX_ENTRIES = 100_000
    private const val BUFFER = 64 * 1024
    private const val PROGRESS_STEP = 256 * 1024

    private fun openZip(input: InputStream): ZipInputStream {
        val buffered = BufferedInputStream(input, BUFFER)
        buffered.mark(4)
        val magic = ByteArray(4)
        var read = 0
        while (read < 4) {
            val n = buffered.read(magic, read, 4 - read)
            if (n < 0) break
            read += n
        }
        buffered.reset()
        val p = 'P'.code.toByte()
        val k = 'K'.code.toByte()
        val valid = read >= 4 && magic[0] == p && magic[1] == k &&
            ((magic[2] == 3.toByte() && magic[3] == 4.toByte()) ||
                (magic[2] == 5.toByte() && magic[3] == 6.toByte()))
        if (!valid) throw ArchiveException("Not a ZIP archive (bad file signature)")
        return ZipInputStream(buffered)
    }

    fun list(input: InputStream, maxEntries: Int = DEFAULT_MAX_ENTRIES): List<ZipItem> {
        val items = ArrayList<ZipItem>()
        try {
            openZip(input).use { zin ->
                var entry = zin.nextEntry
                while (entry != null) {
                    if (items.size >= maxEntries) throw ArchiveException("Too many entries (limit $maxEntries)")
                    items += ZipItem(entry.name, entry.isDirectory, entry.size, entry.compressedSize)
                    entry = zin.nextEntry
                }
            }
        } catch (e: ArchiveException) {
            throw e
        } catch (e: IOException) {
            throw ArchiveException("Corrupted archive: ${e.message}", e)
        } catch (e: IllegalArgumentException) {
            throw ArchiveException("Corrupted archive: ${e.message}", e)
        }
        return items
    }

    fun extract(
        input: InputStream,
        target: ExtractTarget,
        overwrite: OverwritePolicy = OverwritePolicy.SKIP,
        maxTotalBytes: Long = DEFAULT_MAX_TOTAL_BYTES,
        maxEntries: Int = DEFAULT_MAX_ENTRIES,
        onProgress: (bytesWritten: Long) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): ExtractResult {
        var files = 0
        var dirs = 0
        var skipped = 0
        var total = 0L
        var count = 0
        var lastReport = 0L
        val buf = ByteArray(BUFFER)
        try {
            openZip(input).use { zin ->
                var entry: ZipEntry? = zin.nextEntry
                while (entry != null) {
                    if (isCancelled()) throw OperationCancelledException()
                    count++
                    if (count > maxEntries) throw ArchiveException("Too many entries (limit $maxEntries)")
                    val safe = PathSafety.sanitizeEntryName(entry.name)
                        ?: throw ArchiveException("Blocked unsafe entry path: ${entry.name}")

                    if (entry.isDirectory) {
                        target.createDirectory(safe)
                        dirs++
                    } else if (target.exists(safe)) {
                        if (overwrite == OverwritePolicy.FAIL) throw ArchiveException("Already exists: $safe")
                        skipped++
                    } else {
                        var completed = false
                        try {
                            target.openOutput(safe).use { out ->
                                while (true) {
                                    val n = zin.read(buf)
                                    if (n < 0) break
                                    total += n
                                    if (total > maxTotalBytes) throw ArchiveException("Extracted size exceeds safety limit")
                                    out.write(buf, 0, n)
                                    if (total - lastReport >= PROGRESS_STEP) {
                                        lastReport = total
                                        onProgress(total)
                                        if (isCancelled()) throw OperationCancelledException()
                                    }
                                }
                            }
                            completed = true
                        } finally {
                            if (!completed) runCatching { target.delete(safe) } // never leave half-written files
                        }
                        files++
                    }
                    entry = zin.nextEntry
                }
            }
            onProgress(total)
        } catch (e: ArchiveException) {
            throw e
        } catch (e: IOException) {
            throw ArchiveException("Archive error: ${e.message}", e)
        } catch (e: IllegalArgumentException) {
            throw ArchiveException("Corrupted archive: ${e.message}", e)
        }
        return ExtractResult(files, dirs, skipped, total)
    }

    /** Writes a new ZIP to [output]. Returns number of entries written. Duplicate names are skipped. */
    fun create(
        sources: List<ZipSource>,
        output: OutputStream,
        onProgress: (bytesRead: Long) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): Int {
        val seen = HashSet<String>()
        val buf = ByteArray(BUFFER)
        var written = 0
        var total = 0L
        var lastReport = 0L
        try {
            ZipOutputStream(BufferedOutputStream(output, BUFFER)).use { zos ->
                for (src in sources) {
                    if (isCancelled()) throw OperationCancelledException()
                    val safe = PathSafety.sanitizeEntryName(src.path)
                        ?: throw ArchiveException("Invalid entry path: ${src.path}")
                    val name = if (src.isDirectory) "$safe/" else safe
                    if (!seen.add(name)) continue
                    zos.putNextEntry(ZipEntry(name))
                    if (!src.isDirectory) {
                        val ins = src.open() ?: throw ArchiveException("Cannot read ${src.path}")
                        ins.use {
                            while (true) {
                                val n = it.read(buf)
                                if (n < 0) break
                                zos.write(buf, 0, n)
                                total += n
                                if (total - lastReport >= PROGRESS_STEP) {
                                    lastReport = total
                                    onProgress(total)
                                    if (isCancelled()) throw OperationCancelledException()
                                }
                            }
                        }
                    }
                    zos.closeEntry()
                    written++
                }
            }
            onProgress(total)
        } catch (e: ArchiveException) {
            throw e
        } catch (e: IOException) {
            throw ArchiveException("Could not write archive: ${e.message}", e)
        }
        return written
    }
}
