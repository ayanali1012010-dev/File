package com.nexa.toolkit.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.nexa.toolkit.data.FileEntry
import com.nexa.toolkit.ui.theme.NexaTheme
import com.nexa.toolkit.util.formatDate
import com.nexa.toolkit.util.formatSize

@Composable
fun NexaApp(vm: BrowserViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var dark by rememberSaveable { mutableStateOf(true) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) vm.onRootPicked(uri)
    }
    NexaTheme(darkTheme = dark) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            if (state.crumbs.isEmpty()) {
                WelcomeScreen(onPick = { picker.launch(null) })
            } else {
                BrowserScreen(state, vm, dark, onToggleTheme = { dark = !dark }, onPickRoot = { picker.launch(null) })
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.FolderOpen, null, Modifier.padding(bottom = 16.dp), tint = MaterialTheme.colorScheme.primary)
        Text("NEXA Toolkit", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Choose a folder to work in. Access is granted through Android's system picker, " +
                "so the app only sees what you select.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 16.dp),
        )
        Button(onClick = onPick) { Text("Choose folder") }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun BrowserScreen(
    state: BrowserUiState,
    vm: BrowserViewModel,
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onPickRoot: () -> Unit,
) {
    val context = LocalContext.current
    val snackbar = remember { SnackbarHostState() }
    var searching by rememberSaveable { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var showNewFolder by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileEntry?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val selecting = state.selected.isNotEmpty()
    val selectedEntries = state.entries.filter { it.uri in state.selected }
    val visible = state.visible

    BackHandler(enabled = selecting || searching || state.crumbs.size > 1) {
        when {
            selecting -> vm.clearSelection()
            searching -> { searching = false; vm.setQuery("") }
            else -> vm.goUp()
        }
    }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    when {
                        selecting -> Text("${state.selected.size} selected")
                        searching -> TextField(
                            value = state.query,
                            onValueChange = vm::setQuery,
                            singleLine = true,
                            placeholder = { Text("Search by name") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent,
                                unfocusedContainerColor = Color.Transparent,
                            ),
                        )
                        else -> Text(state.crumbs.last().name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                navigationIcon = {
                    when {
                        selecting -> IconButton(onClick = vm::clearSelection) { Icon(Icons.Filled.Close, "Clear selection") }
                        searching -> IconButton(onClick = { searching = false; vm.setQuery("") }) { Icon(Icons.Filled.Close, "Close search") }
                        state.crumbs.size > 1 -> IconButton(onClick = vm::goUp) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Up one folder") }
                    }
                },
                actions = {
                    if (selecting) {
                        val single = selectedEntries.singleOrNull()
                        if (single != null && !single.isDirectory) {
                            IconButton(onClick = { share(context, single) }) { Icon(Icons.Filled.Share, "Share") }
                        }
                        if (single != null) {
                            IconButton(onClick = { renameTarget = single }) { Icon(Icons.Filled.Edit, "Rename") }
                        }
                        IconButton(onClick = vm::compressSelected) { Icon(Icons.Filled.Archive, "Compress to ZIP") }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete") }
                    } else {
                        IconButton(onClick = { searching = true }) { Icon(Icons.Filled.Search, "Search") }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                SortKey.entries.forEach { key ->
                                    val mark = if (state.sortKey == key) (if (state.sortAsc) " ▲" else " ▼") else ""
                                    DropdownMenuItem(
                                        text = { Text(key.name.lowercase().replaceFirstChar { it.uppercase() } + mark) },
                                        onClick = { vm.setSort(key); sortMenu = false },
                                    )
                                }
                            }
                        }
                        IconButton(onClick = vm::refresh) { Icon(Icons.Filled.Refresh, "Refresh") }
                        IconButton(onClick = onToggleTheme) {
                            Icon(if (dark) Icons.Filled.LightMode else Icons.Filled.DarkMode, "Toggle theme")
                        }
                        IconButton(onClick = onPickRoot) { Icon(Icons.Filled.FolderOpen, "Choose another folder") }
                    }
                },
            )
        },
        floatingActionButton = {
            if (!selecting) {
                FloatingActionButton(onClick = { showNewFolder = true }) { Icon(Icons.Filled.CreateNewFolder, "New folder") }
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyRow(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                itemsIndexed(state.crumbs) { index, crumb ->
                    TextButton(onClick = { vm.goToCrumb(index) }) {
                        Text(crumb.name + if (index < state.crumbs.lastIndex) "  ›" else "", maxLines = 1)
                    }
                }
            }
            Box(Modifier.fillMaxSize()) {
                when {
                    state.error != null -> CenterText(state.error, onRetry = vm::refresh)
                    state.loading && state.entries.isEmpty() -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    visible.isEmpty() -> CenterText(if (state.query.isBlank()) "This folder is empty" else "No files match \"${state.query}\"")
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        items(visible, key = { it.uri.toString() }) { entry ->
                            val isSelected = entry.uri in state.selected
                            ListItem(
                                modifier = Modifier.combinedClickable(
                                    onClick = { if (selecting) vm.toggleSelect(entry.uri) else vm.open(entry) },
                                    onLongClick = { vm.toggleSelect(entry.uri) },
                                ),
                                leadingContent = {
                                    Icon(
                                        when {
                                            entry.isDirectory -> Icons.Filled.Folder
                                            entry.isZipContainer -> Icons.Filled.Archive
                                            else -> Icons.AutoMirrored.Filled.InsertDriveFile
                                        },
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                    )
                                },
                                headlineContent = { Text(entry.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                supportingContent = {
                                    Text(
                                        if (entry.isDirectory) "Folder" else "${formatSize(entry.size)}  •  ${formatDate(entry.lastModified)}",
                                        maxLines = 1,
                                    )
                                },
                                trailingContent = { if (selecting) Checkbox(checked = isSelected, onCheckedChange = null) },
                                colors = ListItemDefaults.colors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent,
                                ),
                            )
                        }
                    }
                }
            }
        }
    }

    if (showNewFolder) {
        NameDialog("New folder", "", "Create", { showNewFolder = false }) { vm.createFolder(it); showNewFolder = false }
    }
    renameTarget?.let { target ->
        NameDialog("Rename", target.name, "Rename", { renameTarget = null }) { vm.rename(target, it); renameTarget = null }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${state.selected.size} item(s)?") },
            text = { Text("This permanently deletes the selected items, including folder contents. It cannot be undone.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.deleteSelected() }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
    state.zipPreview?.let { preview ->
        AlertDialog(
            onDismissRequest = vm::dismissZipPreview,
            title = { Text(preview.source.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    val files = preview.items.count { !it.isDirectory }
                    Text("$files file(s), ${preview.items.size - files} folder(s)", style = MaterialTheme.typography.labelLarge)
                    LazyColumn(Modifier.heightIn(max = 320.dp).padding(top = 8.dp)) {
                        items(preview.items.take(500)) { item ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                if (!item.isDirectory) Text(formatSize(item.size), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        if (preview.items.size > 500) item { Text("…and ${preview.items.size - 500} more", style = MaterialTheme.typography.bodySmall) }
                    }
                    Text(
                        "Extracts into a new folder next to the archive. Existing files are never overwritten.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.extractZip(preview.source) }) { Text("Extract") } },
            dismissButton = { TextButton(onClick = vm::dismissZipPreview) { Text("Close") } },
        )
    }
    state.task?.let { task ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(task.title) },
            text = {
                Column {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    // Total size is not known up front for streamed ZIPs, so show bytes actually processed.
                    Text("${formatSize(task.bytes)} processed", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { TextButton(onClick = vm::cancelTask) { Text("Cancel") } },
        )
    }
}

@Composable
private fun CenterText(text: String, onRetry: (() -> Unit)? = null) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (onRetry != null) TextButton(onClick = onRetry) { Text("Retry") }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = text, onValueChange = { text = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

private fun share(context: Context, entry: FileEntry) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = entry.mime ?: "*/*"
        putExtra(Intent.EXTRA_STREAM, entry.uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try {
        context.startActivity(Intent.createChooser(send, entry.name))
    } catch (_: Exception) {
        // No handler available; nothing else to do.
    }
}
