package com.nexa.toolkit.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.nexa.toolkit.archive.ArchiveException
import com.nexa.toolkit.archive.ExtractResult
import com.nexa.toolkit.archive.OverwritePolicy
import com.nexa.toolkit.archive.ZipEngine
import com.nexa.toolkit.archive.ZipItem
import com.nexa.toolkit.archive.ZipSource
import com.nexa.toolkit.util.PathSafety
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException
import kotlin.coroutines.coroutineContext

data class ExtractSummary(val folderName: String, val result: ExtractResult)
data class CompressSummary(val archiveName: String, val entries: Int)

/** All storage access goes through SAF URIs the user explicitly granted. */
class FileRepository(private val context: Context) {

    fun persistPermission(treeUri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Provider does not support persistence; access still works for this session.
        }
    }

    private fun doc(uri: Uri): DocumentFile =
        DocumentFile.fromTreeUri(context, uri) ?: throw IOException("Location is not accessible")

    fun displayName(uri: Uri): String = DocumentFile.fromTreeUri(context, uri)?.name ?: "Storage"

    suspend fun list(dir: Uri): Result<List<FileEntry>> = withContext(Dispatchers.IO) {
        runCatching {
            val d = doc(dir)
            if (!d.isDirectory) throw IOException("Not a folder")
            d.listFiles().mapNotNull { f ->
                val name = f.name ?: return@mapNotNull null
                FileEntry(f.uri, name, f.isDirectory, if (f.isDirectory) 0L else f.length(), f.lastModified(), f.type)
            }
        }
    }

    suspend fun createFolder(parent: Uri, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(PathSafety.isValidFileName(name)) { "Invalid folder name" }
            val p = doc(parent)
            if (p.findFile(name) != null) throw IOException("\"$name\" already exists")
            p.createDirectory(name) ?: throw IOException("Could not create folder")
            Unit
        }
    }

    suspend fun rename(uri: Uri, newName: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(PathSafety.isValidFileName(newName)) { "Invalid name" }
            val d = doc(uri)
            val parent = d.parentFile
            if (parent?.findFile(newName) != null) throw IOException("\"$newName\" already exists")
            if (!d.renameTo(newName)) throw IOException("Rename failed (provider may not support it)")
        }
    }

    /** Returns the number of items actually deleted; failures are reported, never hidden. */
    suspend fun delete(uris: List<Uri>): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            var ok = 0
            val failed = ArrayList<String>()
            for (u in uris) {
                val d = doc(u)
                if (d.delete()) ok++ else failed += (d.name ?: u.toString())
            }
            if (failed.isNotEmpty()) throw IOException("Could not delete: ${failed.joinToString()}")
            ok
        }
    }

    suspend fun listZip(uri: Uri): Result<List<ZipItem>> = withContext(Dispatchers.IO) {
        runCatching {
            context.contentResolver.openInputStream(uri)?.use { ZipEngine.list(it) }
                ?: throw IOException("Cannot open file")
        }
    }

    /** Extracts into a NEW uniquely-named folder next to the archive; nothing existing is overwritten. */
    suspend fun extractZip(zip: FileEntry, parentDir: Uri, onProgress: (Long) -> Unit): Result<ExtractSummary> =
        withContext(Dispatchers.IO) {
            val job = coroutineContext[Job]
            try {
                val parent = doc(parentDir)
                val base = zip.name.substringBeforeLast('.', zip.name)
                val folderName = uniqueName(parent, base, "")
                val dir = parent.createDirectory(folderName) ?: throw IOException("Cannot create output folder")
                val target = DocumentTreeTarget(context, dir)
                val result = context.contentResolver.openInputStream(zip.uri)?.use { input ->
                    ZipEngine.extract(
                        input, target, OverwritePolicy.SKIP,
                        onProgress = onProgress, isCancelled = { job?.isActive == false },
                    )
                } ?: throw IOException("Cannot open archive")
                Result.success(ExtractSummary(folderName, result))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    /** Compresses the given entries (folders recursively) into a new ZIP; never overwrites. */
    suspend fun createZip(entries: List<FileEntry>, parentDir: Uri, onProgress: (Long) -> Unit): Result<CompressSummary> =
        withContext(Dispatchers.IO) {
            val job = coroutineContext[Job]
            var outDoc: DocumentFile? = null
            var success = false
            try {
                val parent = doc(parentDir)
                val sources = ArrayList<ZipSource>()
                for (e in entries) collect(doc(e.uri), "", sources)
                val base = if (entries.size == 1) entries[0].name.substringBeforeLast('.', entries[0].name) else "Archive"
                val finalName = uniqueName(parent, base, ".zip")
                outDoc = parent.createFile("application/zip", finalName) ?: throw IOException("Cannot create archive file")
                val count = context.contentResolver.openOutputStream(outDoc.uri)?.let { out ->
                    ZipEngine.create(sources, out, onProgress) { job?.isActive == false }
                } ?: throw IOException("Cannot write archive")
                success = true
                Result.success(CompressSummary(finalName, count))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                if (!success) runCatching { outDoc?.delete() } // remove incomplete archive
            }
        }

    private fun collect(d: DocumentFile, prefix: String, out: MutableList<ZipSource>) {
        val name = d.name ?: return
        val path = prefix + name
        if (d.isDirectory) {
            out += ZipSource(path, true) { null }
            d.listFiles().forEach { collect(it, "$path/", out) }
        } else {
            out += ZipSource(path, false) { context.contentResolver.openInputStream(d.uri) }
        }
    }

    private fun uniqueName(parent: DocumentFile, base: String, ext: String): String {
        var candidate = base + ext
        var i = 1
        while (parent.findFile(candidate) != null) {
            candidate = "$base ($i)$ext"
            i++
        }
        return candidate
    }
}

/** Translates exceptions into messages a user can act on. */
fun describeError(e: Throwable): String = when (e) {
    is SecurityException -> "Permission denied. Pick the folder again to re-grant access."
    is ArchiveException -> e.message ?: "Archive error"
    is IllegalArgumentException -> e.message ?: "Invalid input"
    else -> e.message ?: e.javaClass.simpleName
}
