package com.nexa.toolkit.archive

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream

/** [ExtractTarget] backed by java.io.File. Re-checks containment as a second line of defence. */
class FileSystemTarget(root: File) : ExtractTarget {
    private val canonicalRoot: File = root.canonicalFile

    private fun resolve(path: String): File {
        val f = File(canonicalRoot, path).canonicalFile
        if (!f.path.startsWith(canonicalRoot.path + File.separator)) {
            throw ArchiveException("Path escapes target folder: $path")
        }
        return f
    }

    override fun exists(path: String) = resolve(path).exists()

    override fun createDirectory(path: String) {
        val d = resolve(path)
        if (!d.isDirectory && !d.mkdirs()) throw IOException("Cannot create folder: $path")
    }

    override fun openOutput(path: String): OutputStream {
        val f = resolve(path)
        f.parentFile?.let { if (!it.isDirectory && !it.mkdirs()) throw IOException("Cannot create folder for: $path") }
        return FileOutputStream(f)
    }

    override fun delete(path: String) {
        resolve(path).delete()
    }
}
