package com.nexa.toolkit.data

import android.content.Context
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.nexa.toolkit.archive.ExtractTarget
import java.io.IOException
import java.io.OutputStream

/** Extraction target writing into a SAF directory. Caches lookups so large archives stay fast. */
class DocumentTreeTarget(private val context: Context, private val root: DocumentFile) : ExtractTarget {
    private val cache = HashMap<String, DocumentFile>()

    private fun find(path: String): DocumentFile? {
        if (path.isEmpty()) return root
        cache[path]?.let { return it }
        var cur: DocumentFile = root
        var prefix = ""
        for (part in path.split('/')) {
            prefix = if (prefix.isEmpty()) part else "$prefix/$part"
            cur = cache[prefix] ?: (cur.findFile(part) ?: return null).also { cache[prefix] = it }
        }
        return cur
    }

    override fun exists(path: String) = find(path) != null

    override fun createDirectory(path: String) {
        var cur: DocumentFile = root
        var prefix = ""
        for (part in path.split('/')) {
            prefix = if (prefix.isEmpty()) part else "$prefix/$part"
            val existing = cache[prefix] ?: cur.findFile(part)
            cur = when {
                existing != null && existing.isDirectory -> existing
                existing != null -> throw IOException("A file already exists where folder is needed: $prefix")
                else -> cur.createDirectory(part) ?: throw IOException("Cannot create folder: $prefix")
            }
            cache[prefix] = cur
        }
    }

    override fun openOutput(path: String): OutputStream {
        val parentPath = path.substringBeforeLast('/', "")
        val name = path.substringAfterLast('/')
        if (parentPath.isNotEmpty()) createDirectory(parentPath)
        val parent = find(parentPath) ?: throw IOException("Parent folder missing: $parentPath")
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val file = parent.createFile(mime, name) ?: throw IOException("Cannot create file: $path")
        cache[path] = file
        return context.contentResolver.openOutputStream(file.uri) ?: throw IOException("Cannot write: $path")
    }

    override fun delete(path: String) {
        cache.remove(path)?.delete() ?: find(path)?.delete()
    }
}
