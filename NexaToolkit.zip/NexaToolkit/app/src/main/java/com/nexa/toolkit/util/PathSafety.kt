package com.nexa.toolkit.util

/** Central validation for archive entry names and user-typed file names. */
object PathSafety {

    /**
     * Normalises an archive entry name to a relative, forward-slash path.
     * Returns null if the name is unsafe (absolute, drive-letter, contains "..", NUL, or empty).
     */
    fun sanitizeEntryName(raw: String): String? {
        if (raw.isEmpty() || raw.indexOf('\u0000') >= 0) return null
        val normalized = raw.replace('\\', '/')
        if (normalized.startsWith("/")) return null
        val parts = normalized.split('/').filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty()) return null
        if (parts.any { it == ".." }) return null
        if (Regex("^[A-Za-z]:").containsMatchIn(parts[0])) return null
        return parts.joinToString("/")
    }

    /** Validates a single file or folder name typed by the user. */
    fun isValidFileName(name: String): Boolean {
        if (name.isBlank() || name == "." || name == "..") return false
        if (name.length > 255) return false
        return name.none { it == '/' || it == '\\' || it == '\u0000' }
    }
}
