package com.nexa.toolkit.data

import android.net.Uri

data class FileEntry(
    val uri: Uri,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
    val mime: String?,
) {
    val extension: String get() = name.substringAfterLast('.', "").lowercase()

    /** ZIP-format containers this build can list/extract. APK and JAR are ZIP files. */
    val isZipContainer: Boolean get() = !isDirectory && extension in setOf("zip", "apk", "jar")
}
