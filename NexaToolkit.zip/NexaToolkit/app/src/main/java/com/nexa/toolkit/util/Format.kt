package com.nexa.toolkit.util

import java.text.DateFormat
import java.util.Date

fun formatSize(bytes: Long): String {
    if (bytes < 0) return "unknown"
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var i = -1
    while (value >= 1024 && i < units.lastIndex) { value /= 1024; i++ }
    return String.format("%.1f %s", value, units[i])
}

fun formatDate(millis: Long): String =
    if (millis <= 0) "" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(millis))
