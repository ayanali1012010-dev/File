package com.nexa.toolkit.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nexa.toolkit.archive.ZipItem
import com.nexa.toolkit.data.FileEntry
import com.nexa.toolkit.data.FileRepository
import com.nexa.toolkit.data.describeError
import com.nexa.toolkit.util.formatSize
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.coroutines.cancellation.CancellationException

data class Crumb(val uri: Uri, val name: String)
enum class SortKey { NAME, SIZE, DATE, TYPE }
data class ZipPreview(val source: FileEntry, val items: List<ZipItem>)
data class TaskState(val title: String, val bytes: Long)

data class BrowserUiState(
    val crumbs: List<Crumb> = emptyList(),
    val entries: List<FileEntry> = emptyList(),
    val loading: Boolean = false,
    val error: String? = null,
    val query: String = "",
    val sortKey: SortKey = SortKey.NAME,
    val sortAsc: Boolean = true,
    val selected: Set<Uri> = emptySet(),
    val zipPreview: ZipPreview? = null,
    val task: TaskState? = null,
    val message: String? = null,
) {
    val visible: List<FileEntry>
        get() {
            val q = query.trim()
            val filtered = if (q.isEmpty()) entries else entries.filter { it.name.contains(q, ignoreCase = true) }
            val cmp: Comparator<FileEntry> = when (sortKey) {
                SortKey.NAME -> compareBy<FileEntry> { it.name.lowercase() }
                SortKey.SIZE -> compareBy<FileEntry> { it.size }
                SortKey.DATE -> compareBy<FileEntry> { it.lastModified }
                SortKey.TYPE -> compareBy<FileEntry>({ it.extension }, { it.name.lowercase() })
            }
            val ordered = if (sortAsc) cmp else cmp.reversed()
            return filtered.sortedWith(compareByDescending<FileEntry> { it.isDirectory }.then(ordered))
        }
}

class BrowserViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = FileRepository(app.applicationContext)
    private val _state = MutableStateFlow(BrowserUiState())
    val state: StateFlow<BrowserUiState> = _state.asStateFlow()
    private var taskJob: Job? = null

    private val currentDir: Uri? get() = _state.value.crumbs.lastOrNull()?.uri

    fun onRootPicked(uri: Uri) {
        repo.persistPermission(uri)
        _state.update { BrowserUiState(crumbs = listOf(Crumb(uri, repo.displayName(uri))), sortKey = it.sortKey, sortAsc = it.sortAsc) }
        refresh()
    }

    fun refresh() {
        val current = _state.value.crumbs.lastOrNull() ?: return
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            repo.list(current.uri)
                .onSuccess { list ->
                    _state.update { s ->
                        if (s.crumbs.lastOrNull()?.uri != current.uri) s
                        else s.copy(entries = list, loading = false, selected = emptySet())
                    }
                }
                .onFailure { e ->
                    _state.update { s ->
                        if (s.crumbs.lastOrNull()?.uri != current.uri) s
                        else s.copy(entries = emptyList(), loading = false, error = describeError(e))
                    }
                }
        }
    }

    fun open(entry: FileEntry) {
        when {
            entry.isDirectory -> {
                _state.update { it.copy(crumbs = it.crumbs + Crumb(entry.uri, entry.name), query = "", selected = emptySet()) }
                refresh()
            }
            entry.isZipContainer -> previewZip(entry)
            else -> postMessage("No viewer for this file type in this build. You can share it instead.")
        }
    }

    val canGoUp: Boolean get() = _state.value.crumbs.size > 1

    fun goUp() { if (canGoUp) goToCrumb(_state.value.crumbs.size - 2) }

    fun goToCrumb(index: Int) {
        _state.update { it.copy(crumbs = it.crumbs.take(index + 1), query = "", selected = emptySet()) }
        refresh()
    }

    fun setQuery(q: String) = _state.update { it.copy(query = q) }
    fun setSort(key: SortKey) = _state.update {
        if (it.sortKey == key) it.copy(sortAsc = !it.sortAsc) else it.copy(sortKey = key, sortAsc = true)
    }

    fun toggleSelect(uri: Uri) = _state.update {
        it.copy(selected = if (uri in it.selected) it.selected - uri else it.selected + uri)
    }
    fun clearSelection() = _state.update { it.copy(selected = emptySet()) }
    fun clearMessage() = _state.update { it.copy(message = null) }
    private fun postMessage(m: String) = _state.update { it.copy(message = m) }

    fun createFolder(name: String) {
        val dir = currentDir ?: return
        viewModelScope.launch {
            repo.createFolder(dir, name.trim())
                .onSuccess { postMessage("Folder created"); refresh() }
                .onFailure { postMessage(describeError(it)) }
        }
    }

    fun rename(entry: FileEntry, newName: String) {
        viewModelScope.launch {
            repo.rename(entry.uri, newName.trim())
                .onSuccess { postMessage("Renamed"); refresh() }
                .onFailure { postMessage(describeError(it)) }
        }
    }

    fun deleteSelected() {
        val uris = _state.value.selected.toList()
        if (uris.isEmpty()) return
        viewModelScope.launch {
            repo.delete(uris)
                .onSuccess { postMessage("Deleted $it item(s)") }
                .onFailure { postMessage(describeError(it)) }
            refresh()
        }
    }

    fun previewZip(entry: FileEntry) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            repo.listZip(entry.uri)
                .onSuccess { items -> _state.update { it.copy(loading = false, zipPreview = ZipPreview(entry, items)) } }
                .onFailure { e -> _state.update { it.copy(loading = false, message = "Cannot read archive: ${describeError(e)}") } }
        }
    }

    fun dismissZipPreview() = _state.update { it.copy(zipPreview = null) }

    fun extractZip(entry: FileEntry) {
        val parent = currentDir ?: return
        if (!beginTask("Extracting ${entry.name}")) return
        taskJob = viewModelScope.launch {
            try {
                repo.extractZip(entry, parent, ::reportProgress)
                    .onSuccess { s ->
                        val skipped = if (s.result.skipped > 0) ", ${s.result.skipped} skipped" else ""
                        finishTask("Extracted ${s.result.files} file(s) (${formatSize(s.result.bytes)}) to \"${s.folderName}\"$skipped")
                    }
                    .onFailure { finishTask("Extraction failed: ${describeError(it)}") }
                refresh()
            } catch (c: CancellationException) {
                finishTask("Extraction cancelled. A partial output folder may remain.")
                refresh()
                throw c
            }
        }
    }

    fun compressSelected() {
        val parent = currentDir ?: return
        val entries = _state.value.entries.filter { it.uri in _state.value.selected }
        if (entries.isEmpty() || !beginTask("Creating ZIP")) return
        taskJob = viewModelScope.launch {
            try {
                repo.createZip(entries, parent, ::reportProgress)
                    .onSuccess { finishTask("Created \"${it.archiveName}\" with ${it.entries} entries") }
                    .onFailure { finishTask("ZIP creation failed: ${describeError(it)}") }
                refresh()
            } catch (c: CancellationException) {
                finishTask("ZIP creation cancelled. Incomplete archive was removed.")
                refresh()
                throw c
            }
        }
    }

    fun cancelTask() { taskJob?.cancel() }

    private fun beginTask(title: String): Boolean {
        if (taskJob?.isActive == true) { postMessage("Another task is still running"); return false }
        _state.update { it.copy(zipPreview = null, task = TaskState(title, 0)) }
        return true
    }

    private fun reportProgress(bytes: Long) =
        _state.update { s -> s.task?.let { s.copy(task = it.copy(bytes = bytes)) } ?: s }

    private fun finishTask(msg: String) = _state.update { it.copy(task = null, message = msg) }
}
