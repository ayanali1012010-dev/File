package com.nexa.toolkit.archive

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Random
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class ZipEngineTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun sample(): List<ZipSource> {
        val a = "hello".toByteArray()
        val b = ByteArray(1000) { (it % 251).toByte() }
        return listOf(
            ZipSource("docs/", true) { null },
            ZipSource("docs/a.txt", false) { ByteArrayInputStream(a) },
            ZipSource("docs/deep/b.bin", false) { ByteArrayInputStream(b) },
        )
    }

    private fun build(): ByteArray = ByteArrayOutputStream().also { ZipEngine.create(sample(), it) }.toByteArray()

    @Test fun roundTripPreservesStructureAndContent() {
        val zip = build()
        val items = ZipEngine.list(ByteArrayInputStream(zip))
        assertEquals(listOf("docs/", "docs/a.txt", "docs/deep/b.bin"), items.map { it.name })

        val out = tmp.newFolder("out")
        val r = ZipEngine.extract(ByteArrayInputStream(zip), FileSystemTarget(out))
        assertEquals(2, r.files)
        assertEquals("hello", File(out, "docs/a.txt").readText())
        assertEquals(1000, File(out, "docs/deep/b.bin").length())
        assertEquals(0, r.skipped)
    }

    @Test fun pathTraversalEntryIsBlockedAndNothingEscapes() {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use {
            it.putNextEntry(ZipEntry("../evil.txt")); it.write(1); it.closeEntry()
        }
        val root = tmp.newFolder("root")
        try {
            ZipEngine.extract(ByteArrayInputStream(bos.toByteArray()), FileSystemTarget(root))
            fail("expected ArchiveException")
        } catch (e: ArchiveException) {
            assertTrue(e.message!!.contains("unsafe"))
        }
        assertFalse(File(root.parentFile, "evil.txt").exists())
    }

    @Test fun nonZipInputIsRejected() {
        try {
            ZipEngine.list(ByteArrayInputStream("this is not a zip file".toByteArray()))
            fail("expected ArchiveException")
        } catch (e: ArchiveException) { /* expected */ }
    }

    @Test fun truncatedArchiveReportsCorruptionAndLeavesNoPartialFile() {
        val rnd = ByteArray(60_000).also { Random(42).nextBytes(it) }
        val bos = ByteArrayOutputStream()
        ZipEngine.create(listOf(ZipSource("big.bin", false) { ByteArrayInputStream(rnd) }), bos)
        val full = bos.toByteArray()
        val cut = full.copyOf(full.size / 3)
        val out = tmp.newFolder("trunc")
        try {
            ZipEngine.extract(ByteArrayInputStream(cut), FileSystemTarget(out))
            fail("expected ArchiveException")
        } catch (e: ArchiveException) { /* expected */ }
        assertFalse(File(out, "big.bin").exists())
    }

    @Test fun existingFilesAreSkippedNotOverwritten() {
        val out = tmp.newFolder("exist")
        File(out, "docs").mkdirs()
        File(out, "docs/a.txt").writeText("ORIGINAL")
        val r = ZipEngine.extract(ByteArrayInputStream(build()), FileSystemTarget(out), OverwritePolicy.SKIP)
        assertEquals(1, r.skipped)
        assertEquals("ORIGINAL", File(out, "docs/a.txt").readText())
    }

    @Test fun failPolicyThrowsOnCollision() {
        val out = tmp.newFolder("fail")
        File(out, "docs").mkdirs()
        File(out, "docs/a.txt").writeText("ORIGINAL")
        try {
            ZipEngine.extract(ByteArrayInputStream(build()), FileSystemTarget(out), OverwritePolicy.FAIL)
            fail("expected ArchiveException")
        } catch (e: ArchiveException) { /* expected */ }
        assertEquals("ORIGINAL", File(out, "docs/a.txt").readText())
    }

    @Test fun cancellationStopsExtraction() {
        val out = tmp.newFolder("cancel")
        try {
            ZipEngine.extract(ByteArrayInputStream(build()), FileSystemTarget(out), isCancelled = { true })
            fail("expected cancellation")
        } catch (e: OperationCancelledException) { /* expected */ }
    }

    @Test fun extractionSizeLimitIsEnforced() {
        val out = tmp.newFolder("limit")
        try {
            ZipEngine.extract(ByteArrayInputStream(build()), FileSystemTarget(out), maxTotalBytes = 10)
            fail("expected ArchiveException")
        } catch (e: ArchiveException) { assertTrue(e.message!!.contains("limit")) }
    }

    @Test fun createdZipIsReadableByJavaZipFile() {
        val f = tmp.newFile("x.zip")
        f.writeBytes(build())
        java.util.zip.ZipFile(f).use { z ->
            assertArrayEquals("hello".toByteArray(), z.getInputStream(z.getEntry("docs/a.txt")).readBytes())
        }
    }
}
