package com.nexa.toolkit.archive

import com.nexa.toolkit.util.PathSafety
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PathSafetyTest {
    @Test fun acceptsNormalPaths() {
        assertEquals("a/b/c.txt", PathSafety.sanitizeEntryName("a/b/c.txt"))
        assertEquals("a/b", PathSafety.sanitizeEntryName("./a//b/"))
    }

    @Test fun blocksTraversalAndAbsolutePaths() {
        assertNull(PathSafety.sanitizeEntryName("../evil.txt"))
        assertNull(PathSafety.sanitizeEntryName("a/../../evil.txt"))
        assertNull(PathSafety.sanitizeEntryName("..\\evil.txt"))
        assertNull(PathSafety.sanitizeEntryName("/etc/passwd"))
        assertNull(PathSafety.sanitizeEntryName("C:\\Windows\\x"))
        assertNull(PathSafety.sanitizeEntryName("a\u0000b"))
        assertNull(PathSafety.sanitizeEntryName(""))
    }

    @Test fun validatesFileNames() {
        assertTrue(PathSafety.isValidFileName("photo.jpg"))
        assertFalse(PathSafety.isValidFileName(".."))
        assertFalse(PathSafety.isValidFileName("a/b"))
        assertFalse(PathSafety.isValidFileName("   "))
    }
}
