# NEXA Toolkit (MVP, Phase 1–2 + early Phase 3/4)

Original Android file manager + archive tool. Kotlin, Jetpack Compose (Material 3), MVVM, coroutines/Flow,
Storage Access Framework. **Status: source written but NOT yet compiled or tested** (no Android SDK/Gradle was
available when this was generated). Expect to fix a few compile errors on first build.

## Architecture
- `archive/` – pure-Kotlin ZIP engine (`java.util.zip`, streaming, bounded memory), `ExtractTarget` abstraction.
- `data/` – `FileRepository` (SAF via `DocumentFile`), `DocumentTreeTarget`, `FileEntry`.
- `ui/` – `BrowserViewModel` (state + tasks), Compose screens, theme (dark-first).
- `util/` – `PathSafety` (zip-slip / filename validation), formatting.

minSdk 26, target/compile SDK 35, AGP 8.5.2, Kotlin 2.0.20, Compose BOM 2024.09.00 (all Apache-2.0).
No storage permissions are declared; the user picks a folder with the system picker.

## Build
1. Open the folder in Android Studio (Koala or newer). It will create the Gradle wrapper and sync.
2. Debug APK: `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.
3. Unit tests: `./gradlew testDebugUnitTest`.
4. Release APK: add your own keystore (kept OUTSIDE the repo, passwords via `~/.gradle/gradle.properties`),
   define a `signingConfigs.release` in `app/build.gradle.kts`, then `./gradlew assembleRelease`.
   Never commit a keystore.

## Feature matrix
| Feature | Status |
|---|---|
| Pick folder via SAF, browse, breadcrumbs, up-navigation | Implemented |
| Create folder, rename, delete (with confirmation) | Implemented |
| Multi-select, search by name, sort (name/size/date/type) | Implemented |
| Share single file via Sharesheet | Implemented |
| Dark/light theme toggle, empty/loading/error states | Implemented |
| ZIP list (streaming), extract to new folder, create ZIP | Implemented (untested on device) |
| Zip-slip protection, size/entry limits, corrupt/non-ZIP detection, cancel | Implemented (unit tests written, not yet run) |
| Real progress | Partial: bytes processed shown; no percentage (stream total unknown) |
| Copy / move | Not implemented yet |
| Recent files, dashboard, settings, task queue/retry | Not implemented yet |
| APK listing/extraction (APK is a ZIP) | Partial: entries only; no manifest/metadata decoding |
| Text editor, hex viewer, image preview | Not implemented yet |
| APK entry replacement, rebuild, signing | Not implemented yet |
| 7z / RAR / password-protected archives | Unsupported in this build |
| Compiled AXML / DEX / resources.arsc editing | Unsupported in this build |

## Known limitations
- ZIP listing inflates each entry to skip it (streaming); very large archives list slowly.
- ZIPs with prepended data (self-extracting) are rejected; AES/password ZIPs are unsupported.
- `DocumentFile.listFiles()` is slow on huge folders.
- Extraction never overwrites: it creates `<name>`, `<name> (1)`, … and skips existing files.
- Android/data and Android/obb are only accessible if the system picker allows them.
- Modifying an APK invalidates its signature; a re-signed APK will not update the original installed app.
